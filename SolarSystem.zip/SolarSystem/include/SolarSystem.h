#ifndef SOLARSYSTEM_H
#define SOLARSYSTEM_H

#include "Planet.h"

class SolarSystem {
private:
    Planet* planets[9];
    int numPlanets;
    double animationSpeed;
    double time;
    bool showPluto;
    
    void drawRealisticSun();
    void drawSaturnRings();

public:
    SolarSystem();
    ~SolarSystem();
    void update(double delta);
    void draw();
    void increaseSpeed();
    void decreaseSpeed();
    double getTime() const;
    double getAnimationSpeed() const;
    Planet* getPlanet(int index);
    int getNumPlanets() const;
    void togglePluto();
    bool isPlutoVisible() const;
};

#endif
