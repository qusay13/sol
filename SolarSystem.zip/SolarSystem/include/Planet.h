#ifndef PLANET_H
#define PLANET_H

// هيكل بيانات القمر
struct Moon {
    double orbitRadius;
    double size;
    double speed;
    double color[3];
    const char* name;
    double initialAngle; // زاوية البداية
};

class Planet {
private:
    double orbitRadius;
    double orbitSpeed;
    double size;
    double rotationSpeed;
    double rotation;
    double color[3];
    const char* name;
    int numMoons;
    Moon* moons; // مصفوفة ديناميكية للأقمار
    bool hasRings;
    double ringInnerRadius;
    double ringOuterRadius;
    double ringColor[3];
    double eccentricity;
    double orbitalInclination;
    double axialTilt;
    double longitudeOfPerihelion;
    
    void drawText(double x, double y, double z, const char* text);
    void drawMoons(double time);
    void drawRings();

public:
    Planet(double oRadius, double oSpeed, double sz, double rSpeed, 
           double r, double g, double b, const char* n,
           int moonCount = 0, Moon* moonData = nullptr,
           bool rings = false, double rInner = 0, double rOuter = 0,
           double rR = 0, double rG = 0, double rB = 0,
           double ecc = 0.0, double incl = 0.0, double tilt = 0.0, double lonPeri = 0.0);
    
    ~Planet();
    
    double getOrbitRadius() const;
    double getOrbitSpeed() const;
    double getSize() const;
    const char* getName() const;
    void drawOrbitPath();
    void draw(double time);
    void getPosition(double time, double& x, double& y, double& z);
};

#endif
