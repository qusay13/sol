#ifndef ABOUTRENDERER_H
#define ABOUTRENDERER_H

class AboutRenderer {
public:
    static void draw();
};

#endif
