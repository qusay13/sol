#include "../include/MainApp.h"
#include "../include/MenuRenderer.h"
#include "../include/HowToUseRenderer.h"
#include "../include/AboutRenderer.h"
#include <GL/glut.h>
#include <stdio.h>

MainApp* MainApp::instance = NULL;

MainApp::MainApp() {
    instance = this;
    
    audioMgr = new AudioManager();
    gameState = new GameStateManager();
    windowMgr = new WindowManager();
    camera = new Camera();
    starField = new StarField();
    solarSystem = new SolarSystem();
    renderer = new Renderer(starField, solarSystem, camera);
    inputHandler = new InputHandler(gameState, windowMgr, camera, solarSystem);
}

MainApp::~MainApp() {
    delete inputHandler;
    delete renderer;
    delete solarSystem;
    delete starField;
    delete camera;
    delete windowMgr;
    delete gameState;
    delete audioMgr;
}

void MainApp::init() {
    audioMgr->init();
    renderer->initGL();
    
    printf("╔════════════════════════════════════════════════╗\n");
    printf("║   REALISTIC 3D SOLAR SYSTEM SIMULATION        ║\n");
    printf("╚════════════════════════════════════════════════╝\n\n");
    printf("Press F11 to toggle fullscreen mode\n");
    printf("Use menu to navigate options\n");
    printf("════════════════════════════════════════════════\n\n");
}

void MainApp::run() {
    glutMainLoop();
}

void MainApp::display() {
    switch (gameState->getCurrentState()) {
        case MENU:
            MenuRenderer::draw(gameState->getSelectedButton(), gameState->getMenuAnimTime());
            break;
        case SIMULATION:
            renderer->renderSimulation();
            break;
        case HOW_TO_USE:
            HowToUseRenderer::draw();
            break;
        case ABOUT:
            AboutRenderer::draw();
            break;
    }
}

void MainApp::update() {
    if (gameState->getCurrentState() == SIMULATION) {
        solarSystem->update(0.01);
    }
    gameState->updateMenuAnimTime(0.016f);
    glutPostRedisplay();
}

void MainApp::reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)w / (float)h, 0.1, 200.0);
    glMatrixMode(GL_MODELVIEW);
}

void MainApp::displayCallback() {
    if (instance) instance->display();
}

void MainApp::reshapeCallback(int w, int h) {
    if (instance) instance->reshape(w, h);
}

void MainApp::updateCallback(int value) {
    if (instance) {
        instance->update();
        glutTimerFunc(16, updateCallback, 0);
    }
}

void MainApp::keyboardCallback(unsigned char key, int x, int y) {
    if (instance) instance->inputHandler->handleKeyboard(key, x, y);
}

void MainApp::specialKeysCallback(int key, int x, int y) {
    if (instance) instance->inputHandler->handleSpecialKeys(key, x, y);
}

void MainApp::mouseCallback(int button, int state, int x, int y) {
    if (instance) instance->inputHandler->handleMouse(button, state, x, y);
}

void MainApp::motionCallback(int x, int y) {
    if (instance) instance->inputHandler->handleMouseMotion(x, y);
}

void MainApp::passiveMotionCallback(int x, int y) {
    if (instance) instance->inputHandler->handlePassiveMotion(x, y);
}

void MainApp::setupCallbacks() {
    glutDisplayFunc(displayCallback);
    glutReshapeFunc(reshapeCallback);
    glutKeyboardFunc(keyboardCallback);
    glutSpecialFunc(specialKeysCallback);
    glutMouseFunc(mouseCallback);
    glutMotionFunc(motionCallback);
    glutPassiveMotionFunc(passiveMotionCallback);
    glutTimerFunc(16, updateCallback, 0);
}
