#include "../include/Renderer.h"
#include <GL/glut.h>
#include <math.h>
#include <stdio.h>

const float M_PI_CONST = 3.14159265358979323846f;

Renderer::Renderer(StarField* sf, SolarSystem* ss, Camera* cam) 
    : starField(sf), solarSystem(ss), camera(cam) {}

void Renderer::initGL() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glShadeModel(GL_SMOOTH);
    
    GLfloat lightPos[] = {0.0f, 0.0f, 0.0f, 1.0f};
    GLfloat lightAmbient[] = {0.15f, 0.15f, 0.15f, 1.0f};
    GLfloat lightDiffuse[] = {1.0f, 0.95f, 0.8f, 1.0f};
    GLfloat lightSpecular[] = {1.0f, 1.0f, 0.9f, 1.0f};
    
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpecular);
    
    glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1.0f);
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.0f);
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.0f);
    
    GLfloat matSpecular[] = {0.6f, 0.6f, 0.6f, 1.0f};
    GLfloat matShininess[] = {60.0f};
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpecular);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShininess);
    
    glClearColor(0.0f, 0.0f, 0.02f, 1.0f);
}

void Renderer::renderSimulation() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    
    float camX, camY, camZ, lookX, lookY, lookZ;
    getCameraPosition(camX, camY, camZ, lookX, lookY, lookZ);
    gluLookAt(camX, camY, camZ, lookX, lookY, lookZ, 0.0f, 1.0f, 0.0f);
    
    starField->draw(solarSystem->getTime());
    solarSystem->draw();
    
    renderHUD();
    
    glutSwapBuffers();
}

void Renderer::getCameraPosition(float& camX, float& camY, float& camZ, 
                      float& lookX, float& lookY, float& lookZ) {
    int focusedPlanet = camera->getFocusedPlanet();
    float focusDistance = camera->getFocusDistance();
    double time = solarSystem->getTime();
    
    if (focusedPlanet == -1) {
        lookX = 0.0f;
        lookY = 0.0f;
        lookZ = 0.0f;
        
        float angleY = camera->getAngleY();
        if (camera->getAutoRotate()) {
            angleY = (float)(time * 5.0);
        }
        
        float angleX = camera->getAngleX();
        camX = focusDistance * sin(angleY * M_PI_CONST / 180.0f) * cos(angleX * M_PI_CONST / 180.0f);
        camY = focusDistance * sin(angleX * M_PI_CONST / 180.0f);
        camZ = focusDistance * cos(angleY * M_PI_CONST / 180.0f) * cos(angleX * M_PI_CONST / 180.0f);
    } else if (focusedPlanet >= 0 && focusedPlanet < solarSystem->getNumPlanets()) {
        Planet* planet = solarSystem->getPlanet(focusedPlanet);
        double lookXd, lookYd, lookZd;
        planet->getPosition(time, lookXd, lookYd, lookZd);
        lookX = (float)lookXd;
        lookY = (float)lookYd;
        lookZ = (float)lookZd;
        
        float angleY = camera->getAngleY();
        if (camera->getAutoRotate()) {
            angleY = (float)(time * 5.0);
        }
        
        float angleX = camera->getAngleX();
        float offset = (float)(planet->getSize() * 3.0 + 2.0);
        camX = (float)(lookX + offset * sin(angleY * M_PI_CONST / 180.0f) * cos(angleX * M_PI_CONST / 180.0f));
        camY = (float)(lookY + offset * sin(angleX * M_PI_CONST / 180.0f));
        camZ = (float)(lookZ + offset * cos(angleY * M_PI_CONST / 180.0f) * cos(angleX * M_PI_CONST / 180.0f));
    } else {
        lookX = 0.0f;
        lookY = 0.0f;
        lookZ = 0.0f;
        
        float distance = camera->getDistance();
        float angleY = camera->getAngleY();
        float angleX = camera->getAngleX();
        
        camX = distance * sin(angleY * M_PI_CONST / 180.0f) * cos(angleX * M_PI_CONST / 180.0f);
        camY = distance * sin(angleX * M_PI_CONST / 180.0f);
        camZ = distance * cos(angleY * M_PI_CONST / 180.0f) * cos(angleX * M_PI_CONST / 180.0f);
    }
}

void Renderer::renderHUD() {
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 800, 0, 600);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    
    glColor3f(0.9f, 0.9f, 0.9f);
    glRasterPos2f(10, 580);
    char info[150];
    
    int focusedPlanet = camera->getFocusedPlanet();
    if (focusedPlanet == -1) {
        sprintf(info, "Focused: SUN | Distance: %.1f", camera->getFocusDistance());
    } else if (focusedPlanet >= 0 && focusedPlanet < solarSystem->getNumPlanets()) {
        Planet* planet = solarSystem->getPlanet(focusedPlanet);
        sprintf(info, "Focused: %s | Auto-Rotate: %s", 
               planet->getName(), camera->getAutoRotate() ? "ON" : "OFF");
    } else {
        sprintf(info, "Free Camera | Distance: %.1f", camera->getDistance());
    }
    
    for (char* c = info; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
    }
    
    glRasterPos2f(10, 560);
    char controls[] = "Mouse: Rotate | W/S: Zoom | 0-9: Focus | A: Auto-Rotate | ESC: Menu | F11: Fullscreen";
    for (char* c = controls; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, *c);
    }
    
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_LIGHTING);
}
