#include "../include/StarField.h"
#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>

const float M_PI_CONST = 3.14159265358979323846f;

StarField::StarField() {
    init();
}

void StarField::init() {
    for (int i = 0; i < NUM_STARS; i++) {
        float theta = (rand() % 360) * M_PI_CONST / 180.0f;
        float phi = (rand() % 180) * M_PI_CONST / 180.0f;
        float radius = 80.0f + (rand() % 40);
        
        stars[i][0] = radius * sin(phi) * cos(theta);
        stars[i][1] = radius * sin(phi) * sin(theta);
        stars[i][2] = radius * cos(phi);
    }
}

void StarField::draw(float time) {
    glDisable(GL_LIGHTING);
    glPointSize(1.5f);
    glBegin(GL_POINTS);
    for (int i = 0; i < NUM_STARS; i++) {
        float brightness = 0.7f + 0.3f * sin(time * 2.0f + i * 0.1f);
        glColor3f(brightness, brightness, brightness);
        glVertex3fv(stars[i]);
    }
    glEnd();
    glEnable(GL_LIGHTING);
}
