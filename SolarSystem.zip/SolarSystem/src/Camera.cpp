#include "../include/Camera.h"

Camera::Camera() : distance(50.0f), angleX(20.0f), angleY(0.0f),
           lastMouseX(0), lastMouseY(0), mousePressed(false),
           focusedPlanet(-2), focusDistance(15.0f), autoRotate(false) {}

float Camera::getDistance() const { return distance; }
float Camera::getAngleX() const { return angleX; }
float Camera::getAngleY() const { return angleY; }
int Camera::getFocusedPlanet() const { return focusedPlanet; }
float Camera::getFocusDistance() const { return focusDistance; }
bool Camera::getAutoRotate() const { return autoRotate; }

void Camera::setDistance(float d) { distance = d; }
void Camera::setAngleX(float a) { angleX = a; }
void Camera::setAngleY(float a) { angleY = a; }
void Camera::setFocusedPlanet(int p) { focusedPlanet = p; }
void Camera::setFocusDistance(float d) { focusDistance = d; }
void Camera::toggleAutoRotate() { autoRotate = !autoRotate; }

void Camera::zoomIn(float amount) {
    if (focusedPlanet == -1) {
        focusDistance -= amount;
        if (focusDistance < 8.0f) focusDistance = 8.0f;
    } else {
        distance -= amount;
        if (distance < 5.0f) distance = 5.0f;
    }
}

void Camera::zoomOut(float amount) {
    if (focusedPlanet == -1) {
        focusDistance += amount;
        if (focusDistance > 50.0f) focusDistance = 50.0f;
    } else {
        distance += amount;
        if (distance > 100.0f) distance = 100.0f;
    }
}

void Camera::startDrag(int x, int y) {
    mousePressed = true;
    lastMouseX = x;
    lastMouseY = y;
    autoRotate = false;
}

void Camera::stopDrag() {
    mousePressed = false;
}

void Camera::drag(int x, int y) {
    if (mousePressed) {
        float dx = x - lastMouseX;
        float dy = y - lastMouseY;
        
        angleY += dx * 0.5f;
        angleX += dy * 0.5f;
        
        if (angleX > 89.0f) angleX = 89.0f;
        if (angleX < -89.0f) angleX = -89.0f;
        
        lastMouseX = x;
        lastMouseY = y;
    }
}

bool Camera::isMousePressed() const { return mousePressed; }
