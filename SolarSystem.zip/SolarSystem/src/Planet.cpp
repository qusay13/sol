// تضمين ملف تعريف كلاس الكوكب
#include "../include/Planet.h"
// تضمين مكتبة OpenGL للرسومات
#include <GL/glut.h>
// تضمين مكتبة الرياضيات للدوال الرياضية
#include <math.h>
#include <cstring>

// ثابت رياضي لقيمة π (باي) بدقة عالية
const double M_PI_CONST = 3.1415926535897932384626433832795;

// دالة البناء Constructor - تقوم بإنشاء كوكب جديد
Planet::Planet(double oRadius, double oSpeed, double sz, double rSpeed, 
       double r, double g, double b, const char* n,
       int moonCount, Moon* moonData,
       bool rings, double rInner, double rOuter,
       double rR, double rG, double rB,
       double ecc, double incl, double tilt, double lonPeri)
    : orbitRadius(oRadius), orbitSpeed(oSpeed), size(sz), 
      rotationSpeed(rSpeed), rotation(0.0), name(n),
      numMoons(moonCount), hasRings(rings),
      ringInnerRadius(rInner), ringOuterRadius(rOuter),
      eccentricity(ecc), orbitalInclination(incl), axialTilt(tilt),
      longitudeOfPerihelion(lonPeri) {
    // تعيين لون الكوكب في مصفوفة الألوان
    color[0] = r; // الأحمر
    color[1] = g; // الأخضر
    color[2] = b; // الأزرق
    
    // نسخ بيانات الأقمار
    if (moonCount > 0 && moonData != nullptr) {
        moons = new Moon[moonCount];
        for (int i = 0; i < moonCount; i++) {
            moons[i] = moonData[i];
        }
    } else {
        moons = nullptr;
    }
    
    // تعيين لون الحلقات
    if (hasRings) {
        ringColor[0] = rR;
        ringColor[1] = rG;
        ringColor[2] = rB;
    }
}

// دالة الإتلاف Destructor
Planet::~Planet() {
    if (moons != nullptr) {
        delete[] moons;
    }
}

// دوال Getter - لإرجاع قيم خصائص الكوكب
double Planet::getOrbitRadius() const { return orbitRadius; } // إرجاع نصف قطر المدار
double Planet::getOrbitSpeed() const { return orbitSpeed; }   // إرجاع سرعة الدوران حول الشمس
double Planet::getSize() const { return size; }               // إرجاع حجم الكوكب
const char* Planet::getName() const { return name; }         // إرجاع اسم الكوكب

// دالة رسم مسار المدار الإهليلجي - ترسم مسار الكوكب حول الشمس
void Planet::drawOrbitPath() {
    // إيقاف الإضاءة مؤقتاً لرسم الخط بلون ثابت
    glDisable(GL_LIGHTING);
    // تعيين لون رمادي داكن للمسار
    glColor3f(0.2f, 0.2f, 0.25f);
    // تعيين سمك الخط إلى 1 بكسل
    glLineWidth(1.0f);
    
    // حفظ المصفوفة الحالية
    glPushMatrix();
    // تطبيق الميل المداري (إمالة المدار بزاوية معينة)
    glRotatef((float)orbitalInclination, 1.0f, 0.0f, 0.0f);
    // تدوير المدار بزاوية طول الحضيض لوضع الحضيض في المكان الصحيح
    glRotatef((float)longitudeOfPerihelion, 0.0f, 1.0f, 0.0f);
    
    // حساب المحور شبه الرئيسي (a) والمحور شبه الثانوي (b)
    double a = orbitRadius;
    double b = orbitRadius * sqrt(1.0 - eccentricity * eccentricity);
    
    // بدء رسم حلقة مغلقة من الخطوط
    glBegin(GL_LINE_LOOP);
    // رسم 200 نقطة لتشكيل مدار إهليلجي بدقة أعلى
    for (int i = 0; i < 200; i++) {
        // حساب الزاوية لكل نقطة (360 درجة مقسمة على 200)
        double angle = 2.0 * M_PI_CONST * i / 200.0;
        // استخدام معادلة القطع الناقص البارامترية: x = a*cos(θ), z = b*sin(θ)
        // إزاحة المركز بمقدار ae لجعل الشمس في البؤرة وليس المركز
        double x = a * cos(angle) - a * eccentricity;
        double z = b * sin(angle);
        glVertex3f((float)x, 0.0f, (float)z);
    }
    glEnd(); // إنهاء الرسم
    
    glPopMatrix();
    // إعادة تفعيل الإضاءة
    glEnable(GL_LIGHTING);
}

// دالة حل معادلة كبلر باستخدام Newton-Raphson (أسرع وأدق)
double solveKeplerEquation(double M, double e) {
    double E = M; // القيمة الأولية
    const double tolerance = 1e-10; // دقة عالية
    const int maxIterations = 20;
    
    for (int i = 0; i < maxIterations; i++) {
        double f = E - e * sin(E) - M;
        double fPrime = 1.0 - e * cos(E);
        
        if (fabs(fPrime) < 1e-10) break; // تجنب القسمة على صفر
        
        double delta = f / fPrime;
        E -= delta;
        
        if (fabs(delta) < tolerance) break; // وصلنا للدقة المطلوبة
    }
    
    return E;
}

// دالة رسم الكوكب - ترسم الكوكب في موقعه الحالي بناءً على الوقت
void Planet::draw(double time) {
    double meanAnomaly = time * orbitSpeed;
    
    // استخدام Newton-Raphson لحل معادلة كبلر (أسرع وأدق)
    double E = solveKeplerEquation(meanAnomaly, eccentricity);
    
    // حساب الشذوذ الحقيقي
    double trueAnomaly = 2.0 * atan2(
        sqrt(1.0 + eccentricity) * sin(E / 2.0),
        sqrt(1.0 - eccentricity) * cos(E / 2.0)
    );
    
    // حساب المسافة من الشمس
    double r = orbitRadius * (1.0 - eccentricity * eccentricity) / 
              (1.0 + eccentricity * cos(trueAnomaly));
    
    drawOrbitPath();
    
    glPushMatrix();
    
    glRotatef((float)orbitalInclination, 1.0f, 0.0f, 0.0f);
    glRotatef((float)longitudeOfPerihelion, 0.0f, 1.0f, 0.0f);
    
    double x = r * cos(trueAnomaly);
    double z = r * sin(trueAnomaly);
    
    glTranslatef((float)x, 0.0f, (float)z);
    
    glRotatef((float)axialTilt, 0.0f, 0.0f, 1.0f);
    
    rotation += rotationSpeed * 0.5;
    glRotatef((float)rotation, 0.0f, 1.0f, 0.0f);
    
    // رسم الحلقات قبل الكوكب (إن وجدت)
    if (hasRings) {
        drawRings();
    }
    
    // رسم الكوكب مع تأثيرات بصرية
    glColor3d(color[0], color[1], color[2]);
    
    // رسم الكوكب الأساسي
    glutSolidSphere((float)size, 40, 40);
    
    // إضافة تأثير الغلاف الجوي للكواكب الكبيرة
    if (size > 1.5) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDepthMask(GL_FALSE);
        
        // طبقة غلاف جوي رقيقة
        glColor4f((float)color[0], (float)color[1], (float)color[2], 0.15f);
        glutSolidSphere((float)(size * 1.05), 35, 35);
        
        glDepthMask(GL_TRUE);
        glDisable(GL_BLEND);
    }
    
    drawText(0.0, size + 0.5, 0.0, name);
    
    // رسم الأقمار
    if (numMoons > 0) {
        drawMoons(time);
    }
    
    glPopMatrix();
}

// دالة للحصول على موقع الكوكب في وقت معين
void Planet::getPosition(double time, double& x, double& y, double& z) {
    double meanAnomaly = time * orbitSpeed;
    
    // استخدام Newton-Raphson
    double E = solveKeplerEquation(meanAnomaly, eccentricity);
    
    double trueAnomaly = 2.0 * atan2(
        sqrt(1.0 + eccentricity) * sin(E / 2.0),
        sqrt(1.0 - eccentricity) * cos(E / 2.0)
    );
    
    double r = orbitRadius * (1.0 - eccentricity * eccentricity) / 
              (1.0 + eccentricity * cos(trueAnomaly));
    
    double localX = r * cos(trueAnomaly);
    double localZ = r * sin(trueAnomaly);
    
    double inclinationRad = orbitalInclination * M_PI_CONST / 180.0;
    double lonPeriRad = longitudeOfPerihelion * M_PI_CONST / 180.0;
    
    x = localX * cos(lonPeriRad) - localZ * sin(lonPeriRad);
    y = localZ * sin(inclinationRad);
    z = localX * sin(lonPeriRad) + localZ * cos(lonPeriRad) * cos(inclinationRad);
}

// دالة لرسم نص في الفضاء ثلاثي الأبعاد
void Planet::drawText(double x, double y, double z, const char* text) {
    // إيقاف الإضاءة لرسم النص بوضوح
    glDisable(GL_LIGHTING);
    // تعيين اللون الأبيض للنص
    glColor3f(1.0f, 1.0f, 1.0f);
    // تحديد موقع بدء رسم النص في الفضاء 3D
    glRasterPos3f((float)x, (float)y, (float)z);
    // المرور على كل حرف في النص ورسمه
    while (*text) {
        // رسم الحرف الحالي بخط Helvetica حجم 12
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *text);
        // الانتقال للحرف التالي
        text++;
    }
    // إعادة تفعيل الإضاءة
    glEnable(GL_LIGHTING);
}

// دالة رسم الأقمار
void Planet::drawMoons(double time) {
    for (int i = 0; i < numMoons; i++) {
        double moonAngle = time * moons[i].speed + moons[i].initialAngle;
        double moonX = moons[i].orbitRadius * cos(moonAngle);
        double moonZ = moons[i].orbitRadius * sin(moonAngle);
        
        glPushMatrix();
        glTranslatef((float)moonX, 0.0f, (float)moonZ);
        glColor3d(moons[i].color[0], moons[i].color[1], moons[i].color[2]);
        glutSolidSphere((float)moons[i].size, 20, 20);
        glPopMatrix();
    }
}

// دالة رسم الحلقات
void Planet::drawRings() {
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    // رسم 3 حلقات متداخلة
    for (int j = 0; j < 3; j++) {
        double innerRadius = ringInnerRadius + j * (ringOuterRadius - ringInnerRadius) / 3.0;
        double outerRadius = ringInnerRadius + (j + 1) * (ringOuterRadius - ringInnerRadius) / 3.0;
        double alpha = 0.8 - j * 0.15;
        
        glColor4d(ringColor[0], ringColor[1], ringColor[2], alpha);
        
        glBegin(GL_QUAD_STRIP);
        for (int i = 0; i <= 100; i++) {
            double theta = 2.0 * M_PI_CONST * i / 100.0;
            double cosTheta = cos(theta);
            double sinTheta = sin(theta);
            
            glVertex3f((float)(innerRadius * cosTheta), 0.0f, (float)(innerRadius * sinTheta));
            glVertex3f((float)(outerRadius * cosTheta), 0.0f, (float)(outerRadius * sinTheta));
        }
        glEnd();
    }
    
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);
}
