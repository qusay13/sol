#include "../include/WindowManager.h"
#include <GL/glut.h>
#include <stdio.h>

WindowManager::WindowManager() : isFullscreen(false), windowWidth(800), windowHeight(600), 
                  windowPosX(100), windowPosY(100) {}

void WindowManager::toggleFullscreen() {
    if (!isFullscreen) {
        windowPosX = glutGet(GLUT_WINDOW_X);
        windowPosY = glutGet(GLUT_WINDOW_Y);
        windowWidth = glutGet(GLUT_WINDOW_WIDTH);
        windowHeight = glutGet(GLUT_WINDOW_HEIGHT);
        glutFullScreen();
        isFullscreen = true;
        printf("Fullscreen enabled\n");
    } else {
        glutReshapeWindow(windowWidth, windowHeight);
        glutPositionWindow(windowPosX, windowPosY);
        isFullscreen = false;
        printf("Fullscreen disabled\n");
    }
}

bool WindowManager::getIsFullscreen() const { return isFullscreen; }
