#include "../include/GameStateManager.h"

const int NUM_MENU_BUTTONS = 4;

GameStateManager::GameStateManager() : currentState(MENU), selectedButton(0), menuAnimTime(0.0f) {}

GameState GameStateManager::getCurrentState() const { return currentState; }
void GameStateManager::setCurrentState(GameState state) { currentState = state; }

int GameStateManager::getSelectedButton() const { return selectedButton; }
void GameStateManager::setSelectedButton(int button) { selectedButton = button; }
void GameStateManager::selectPrevious() { selectedButton = (selectedButton - 1 + NUM_MENU_BUTTONS) % NUM_MENU_BUTTONS; }
void GameStateManager::selectNext() { selectedButton = (selectedButton + 1) % NUM_MENU_BUTTONS; }

float GameStateManager::getMenuAnimTime() const { return menuAnimTime; }
void GameStateManager::updateMenuAnimTime(float delta) { menuAnimTime += delta; }
