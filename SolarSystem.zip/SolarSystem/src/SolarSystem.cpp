// تضمين ملف تعريف كلاس النظام الشمسي
#include "../include/SolarSystem.h"
// تضمين مكتبة OpenGL للرسومات
#include <GL/glut.h>
// تضمين مكتبة الرياضيات
#include <math.h>

// ثابت رياضي لقيمة π (باي)
const double M_PI_CONST = 3.1415926535897932384626433832795;

// دالة البناء Constructor - تقوم بإنشاء النظام الشمسي الكامل
// البيانات المستخدمة هنا دقيقة علمياً مع ألوان محسّنة وأقمار متعددة
SolarSystem::SolarSystem() : numPlanets(9), animationSpeed(1.0), time(0.0), showPluto(true) {
    // عطارد - لون رمادي فاتح
    planets[0] = new Planet(4.0, 4.15, 0.38, 1.0, 0.75, 0.75, 0.75, "Mercury", 
                            0, nullptr, false, 0, 0, 0, 0, 0,
                            0.2056, 7.0, 0.034, 77.45);
    
    // الزهرة - لون أصفر-أبيض (سحب حمضية)
    planets[1] = new Planet(7.0, 1.62, 0.95, 0.4, 0.95, 0.95, 0.85, "Venus", 
                            0, nullptr, false, 0, 0, 0, 0, 0,
                            0.0067, 3.4, 177.4, 131.53);
    
    // الأرض - لون أزرق-أخضر (محيطات وقارات)
    Moon earthMoon = {1.5, 0.27, 3.0, {0.7, 0.7, 0.7}, "Moon", 0.0};
    planets[2] = new Planet(10.0, 1.0, 1.0, 1.0, 0.2, 0.5, 0.9, "Earth", 
                            1, &earthMoon, false, 0, 0, 0, 0, 0,
                            0.0167, 0.0, 23.44, 102.94);
    
    // المريخ - لون أحمر-برتقالي
    planets[3] = new Planet(15.0, 0.53, 0.53, 0.97, 0.85, 0.35, 0.25, "Mars", 
                            0, nullptr, false, 0, 0, 0, 0, 0,
                            0.0934, 1.85, 25.19, 336.04);
    
    // المشتري - لون برتقالي-بني مع خطوط
    Moon jupiterMoons[4] = {
        {3.5, 0.15, 2.5, {0.8, 0.7, 0.6}, "Io", 0.0},
        {4.0, 0.12, 2.0, {0.7, 0.8, 0.7}, "Europa", 1.57},
        {5.0, 0.18, 1.5, {0.6, 0.6, 0.7}, "Ganymede", 3.14},
        {6.0, 0.14, 1.2, {0.5, 0.5, 0.6}, "Callisto", 4.71}
    };
    planets[4] = new Planet(25.0, 0.084, 2.5, 2.4, 0.85, 0.65, 0.5, "Jupiter", 
                            4, jupiterMoons, true, 2.8, 3.2, 0.9, 0.85, 0.7,
                            0.0489, 1.3, 3.13, 14.75);
    
    // زحل - لون ذهبي فاتح
    Moon saturnMoons[1] = {
        {3.0, 0.3, 1.8, {0.7, 0.7, 0.6}, "Titan", 0.0}
    };
    planets[5] = new Planet(35.0, 0.034, 2.0, 2.2, 0.95, 0.85, 0.65, "Saturn", 
                            1, saturnMoons, true, 2.8, 3.5, 0.9, 0.85, 0.65,
                            0.0565, 2.49, 26.73, 92.43);
    
    // أورانوس - لون أزرق-أخضر فاتح
    planets[6] = new Planet(42.0, 0.012, 1.2, 1.4, 0.5, 0.75, 0.85, "Uranus", 
                            0, nullptr, true, 1.4, 1.7, 0.7, 0.8, 0.9,
                            0.0457, 0.77, 97.77, 170.96);
    
    // نبتون - لون أزرق عميق
    planets[7] = new Planet(50.0, 0.006, 1.15, 1.2, 0.2, 0.4, 0.95, "Neptune", 
                            0, nullptr, false, 0, 0, 0, 0, 0,
                            0.0113, 1.77, 28.32, 44.97);
    
    // بلوتو - لون بني-رمادي
    Moon plutoMoon = {1.2, 0.12, 1.5, {0.6, 0.6, 0.6}, "Charon", 0.0};
    planets[8] = new Planet(58.0, 0.004, 0.18, 0.8, 0.75, 0.65, 0.55, "Pluto (Dwarf)", 
                            1, &plutoMoon, false, 0, 0, 0, 0, 0,
                            0.2488, 17.16, 122.53, 224.07);
}

// دالة الإتلاف Destructor - تقوم بحذف جميع الكواكب من الذاكرة
SolarSystem::~SolarSystem() {
    for (int i = 0; i < 9; i++) {
        delete planets[i]; // حذف كل كوكب (بما في ذلك بلوتو)
    }
}

// دالة التحديث - تقوم بتحريك الوقت للأمام
// delta: الفترة الزمنية الصغيرة بين كل إطار وإطار (حوالي 0.01 ثانية)
void SolarSystem::update(double delta) {
    // زيادة الوقت بناءً على السرعة المحددة
    // animationSpeed يمكن زيادتها أو تقليلها لتسريع أو تبطيء الحركة
    time += delta * animationSpeed;
}

// دالة الرسم - ترسم الشمس وجميع الكواكب
void SolarSystem::draw() {
    // رسم الشمس أولاً (في المركز)
    drawRealisticSun();
    
    // تحديد عدد الكواكب المراد رسمها
    int planetsToRender = showPluto ? 9 : 8;
    
    // رسم الكواكب (8 كواكب أو 9 مع بلوتو)
    for (int i = 0; i < planetsToRender; i++) {
        planets[i]->draw(time);
    }
    
    // الحلقات تُرسم الآن داخل Planet::draw() لكل كوكب
}

// دالة لتبديل إظهار/إخفاء بلوتو
void SolarSystem::togglePluto() { 
    showPluto = !showPluto;
    // تحديث عدد الكواكب بناءً على حالة بلوتو
    numPlanets = showPluto ? 9 : 8;
}

// إرجاع حالة ظهور بلوتو
bool SolarSystem::isPlutoVisible() const { return showPluto; }

// دالة لزيادة سرعة المحاكاة بمقدار 20%
void SolarSystem::increaseSpeed() { animationSpeed *= 1.2; }

// دالة لتقليل سرعة المحاكاة بمقدار 20%
void SolarSystem::decreaseSpeed() { animationSpeed /= 1.2; }

// إرجاع الوقت الحالي في المحاكاة
double SolarSystem::getTime() const { return time; }

// إرجاع سرعة الحركة الحالية
double SolarSystem::getAnimationSpeed() const { return animationSpeed; }

// الحصول على مؤشر لكوكب معين بناءً على رقمه (0 = عطارد، 7 = نبتون)
Planet* SolarSystem::getPlanet(int index) {
    if (index >= 0 && index < numPlanets) {
        return planets[index];
    }
    return NULL; // إرجاع قيمة فارغة إذا كان الرقم خاطئ
}

// إرجاع عدد الكواكب (8)
int SolarSystem::getNumPlanets() const { return numPlanets; }

// دالة رسم الشمس بمؤثرات بصرية واقعية
void SolarSystem::drawRealisticSun() {
    // حفظ المصفوفة الحالية
    glPushMatrix();
    // إيقاف الإضاءة لرسم الشمس المضيئة
    glDisable(GL_LIGHTING);
    
    // رسم نواة الشمس باللون الأصفر الفاتح
    glColor3f(1.0f, 1.0f, 0.95f);
    glutSolidSphere(2.5, 50, 50); // كرة صلبة بتفاصيل عالية (50 شريحة)
    
    // تفعيل الشفافية لرسم طبقات الهالة المحيطة بالشمس
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE); // دمج الألوان لتأثير التوهج
    glDepthMask(GL_FALSE); // إيقاف كتابة العمق لتداخل الطبقات
    
    // الطبقة الأولى: هالة صفراء فاتحة بشفافية 50%
    glColor4f(1.0f, 0.95f, 0.4f, 0.5f);
    glutSolidSphere(2.8, 40, 40);
    
    // الطبقة الثانية: هالة برتقالية بشفافية 35%
    glColor4f(1.0f, 0.8f, 0.2f, 0.35f);
    glutSolidSphere(3.2, 40, 40);
    
    // الطبقة الثالثة: هالة برتقالية داكنة بشفافية 25%
    glColor4f(1.0f, 0.7f, 0.1f, 0.25f);
    glutSolidSphere(3.8, 40, 40);
    
    // الطبقة الرابعة: هالة برتقالية محمرة بشفافية 15%
    glColor4f(1.0f, 0.6f, 0.0f, 0.15f);
    glutSolidSphere(4.5, 40, 40);
    
    // الطبقة الخامسة: هالة خارجية حمراء برتقالية بشفافية 8%
    glColor4f(1.0f, 0.5f, 0.0f, 0.08f);
    glutSolidSphere(5.5, 40, 40);
    
    // رسم 8 توهجات شمسية متحركة حول الشمس (Solar Flares)
    for (int i = 0; i < 8; i++) {
        // حساب شدة التوهج بشكل متذبذب باستخدام دالة sin
        // هذا يعطي تأثير الوميض للتوهجات الشمسية
        float flareIntensity = 0.3f + 0.2f * (float)sin(time * 3.0 + i);
        
        glPushMatrix();
        // دوران التوهجات حول الشمس بزوايا مختلفة
        glRotatef((float)(i * 45.0 + time * 10.0), 0.0f, 1.0f, 0.0f);
        // وضع التوهج على بعد 3 وحدات من مركز الشمس
        glTranslatef(3.0f, 0.0f, 0.0f);
        // رسم التوهج بلون برتقالي وشدة متغيرة
        glColor4f(1.0f, 0.7f, 0.1f, flareIntensity);
        glutSolidSphere(0.4f, 10, 10); // كرة صغيرة للتوهج
        glPopMatrix();
    }
    
    // إعادة تفعيل كتابة العمق
    glDepthMask(GL_TRUE);
    // إيقاف الشفافية
    glDisable(GL_BLEND);
    // إعادة تفعيل الإضاءة
    glEnable(GL_LIGHTING);
    
    glPopMatrix();
}

// دالة رسم حلقات كوكب زحل (تم نقلها إلى Planet::drawRings)
// هذه الدالة محفوظة للتوافق مع الكود القديم
void SolarSystem::drawSaturnRings() {
    // الحلقات الآن تُرسم داخل Planet::draw()
    // هذه الدالة فارغة للتوافق مع الكود القديم
}
